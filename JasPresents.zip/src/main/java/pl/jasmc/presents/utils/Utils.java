package pl.jasmc.presents.utils;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import net.minecraft.server.v1_12_R1.NBTTagCompound;
import net.minecraft.server.v1_12_R1.NBTTagList;
import net.minecraft.server.v1_12_R1.NBTTagString;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.craftbukkit.v1_12_R1.inventory.CraftItemStack;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class Utils {

    public static void sendColoredInfo(String info) {
        Bukkit.getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes('&', info));
    }


    /*

        createSkull(texture, displayName):
        Zwraca ItemStacka, główke pustą lub z teksturą która jest podana i nazwą



     */

    public static ItemStack createSkull(String texture, String displayName){

        final ItemStack head = new ItemStack(Material.SKULL_ITEM, 1, (short)3);

        if(texture.isEmpty()) {
            return head;
        }
        final SkullMeta skullMeta = (SkullMeta) head.getItemMeta();

        final GameProfile profile = new GameProfile(UUID.randomUUID(), null);
        profile.getProperties().put("textures", new Property("textures", texture));
        try {
            final Field profileField = skullMeta.getClass().getDeclaredField("profile");
            profileField.setAccessible(true);
            profileField.set(skullMeta, profile);

        } catch (IllegalAccessException | NoSuchFieldException e) {
            e.printStackTrace();
        }

        skullMeta.setDisplayName(displayName);
        head.setItemMeta(skullMeta);
        return head;
    }

    public static GameProfile getGameProfile(String url) {
        final GameProfile profile = new GameProfile(UUID.randomUUID(), null);
        profile.getProperties().put("textures", new Property("textures", url));


        return profile;
    }

    public static Location stringToLoc(String location) {
        String[] splitLoc = location.split("/");
        //world;x;y;z
        return new Location(Bukkit.getWorld(splitLoc[0]), Double.parseDouble(splitLoc[1]),Double.parseDouble(splitLoc[2]),Double.parseDouble(splitLoc[3]));
    }

    public static List<Location> stringLocationListToLoc(List<String> locations) {

        List<Location> convertedLocationList = new ArrayList<Location>();
        for(String location : locations) {
            convertedLocationList.add(stringToLoc(location));
            System.out.println("Adding : " + location.toString());
        }
        System.out.println("Returning: " + locations.toString());
        return convertedLocationList;
    }

    public static String locationToString(Location location) {
        return location.getWorld().getName() + "/" + location.getX() + "/" + location.getY() + "/" + location.getZ();
    }



    public static ItemStack setSkullOwner(ItemStack itemStack, String id, String textureValue) {
        net.minecraft.server.v1_12_R1.ItemStack nmsStack = CraftItemStack.asNMSCopy(itemStack);

        NBTTagCompound compound = nmsStack.getTag();
        if (compound == null) {
            compound = new NBTTagCompound();
            nmsStack.setTag(compound);
            compound = nmsStack.getTag();
        }

        NBTTagCompound skullOwner = new NBTTagCompound();
        skullOwner.set("Id", new NBTTagString(id));
        NBTTagCompound properties = new NBTTagCompound();
        NBTTagList textures = new NBTTagList();
        NBTTagCompound value = new NBTTagCompound();
        value.set("Value", new NBTTagString(textureValue));
        textures.add(value);
        properties.set("textures", textures);
        skullOwner.set("Properties", properties);

        compound.set("SkullOwner", skullOwner);
        nmsStack.setTag(compound);

        return CraftItemStack.asBukkitCopy(nmsStack);
    }



}
