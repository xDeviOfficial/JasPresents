package pl.jasmc.presents.utils;

public class Yamler {
}
