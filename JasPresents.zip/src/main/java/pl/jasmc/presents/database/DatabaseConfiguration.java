package pl.jasmc.presents.database;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import pl.jasmc.presents.Presents;
import pl.jasmc.presents.enums.PresentType;
import pl.jasmc.presents.managers.DataManager;
import pl.jasmc.presents.objects.Present;
import pl.jasmc.presents.utils.Utils;

import java.sql.*;
import java.util.List;

public class DatabaseConfiguration {

    private static Statement stm;
    private static Presents ab = Presents.getInstance();


    public static void checkTable() throws SQLException {
        Connection connection = ab.getHikari().getConnection();
        stm = connection.createStatement();
        stm.executeUpdate("create table if not exists JasPresentsUsers (uuid varchar(100) not null primary key, nickname varchar(100), collected int(2));");
        stm.executeUpdate("create table if not exists JasPresents (id int(2) not null AUTO_INCREMENT, location varchar(100), present_name varchar(32), present_type varchar(10), PRIMARY KEY(id));");
    }

    public static void createPresent(String location, String name) throws SQLException {
        stm.executeUpdate("INSERT INTO JasPresents VALUES  ()");
    }







    public void savePassword(Player p, String password) throws SQLException {
        stm.executeUpdate("insert ignore into JasCore values (\"" + p.getUniqueId() + "\", " + 0 + ", " + 0 + ")");
        PreparedStatement sql = stm.getConnection().prepareStatement("UPDATE AzenisBansAdmin set nickname = ?, password = ? where uuid = ?");
        sql.setString(1, p.getName());
        sql.setString(2, password);
        sql.setString(3, p.getUniqueId().toString());
        sql.execute();
        sql.close();
    }
    public String getPassword(Player p) throws SQLException {
        ResultSet rs = stm.executeQuery("select password from AzenisBansAdmin where uuid = \"" + p.getUniqueId().toString() + "\"");
        rs.beforeFirst();
        rs.next();
        return rs.getString("password");
    }

    public void test() {

    }

    public static void addPresent(String location, String name, String type) throws SQLException  {
        String query = "INSERT INTO JasPresents (location, present_name, present_type) VALUES (\"" +  location + "\",\"" + name + "\",\"" + type + "\")";
        System.out.println("Query: " + query);
        stm.executeUpdate(query);
    }


    public static void loadPresents() throws SQLException {
        ResultSet rs = stm.executeQuery("SELECT * FROM JasPresents");
        int i = 0;
        while(rs.next()) {

            Present present = new Present(rs.getString("present_name"), PresentType.valueOf(rs.getString("present_type").toUpperCase()), Utils.stringToLoc(rs.getString("location")));
            DataManager.addPresent(present);
            i++;
        }

        System.out.println("Załadowano: " + i + " prezentow");


    }


}
