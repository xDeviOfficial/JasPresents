package pl.jasmc.presents.objects;

import pl.jasmc.presents.managers.DataManager;

import java.util.ArrayList;
import java.util.List;

public class JPlayer {

    public String UUID;
    public String name;
    public List<Present> presentsFound;
    public List<Present> presentsToFind;


    public JPlayer(String uuid, String name) {
        this.UUID = uuid;
        this.name = name;
        this.presentsToFind = new ArrayList<>();
        for(Present present : DataManager.loadedPresenents) {
            this.presentsToFind.add(present);
        }

    }




}
