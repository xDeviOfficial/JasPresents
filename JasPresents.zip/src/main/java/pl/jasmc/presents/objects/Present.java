package pl.jasmc.presents.objects;

import org.bukkit.Location;
import pl.jasmc.presents.enums.PresentType;

public class Present {

    public String name;
    public PresentType type;
    public Location location;
    public String textureID;


    public Present(String name, PresentType type, Location location) {
        this.name = name;
        this.type = type;
        this.location = location;
        switch(type) {
            case ORANGE: this.textureID = "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZGVmMGVkOWQ1ODY1ZjE5Nzc5NzMxZjhhYWI1YTg5YzJkYjJjNjkyZWQyN2JkNGFhNGE5MjgyMmQ1MDc2ZGZmNyJ9fX0=";
            case GREEN: this.textureID = "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZjA5NjcwZDM1MWQ3ODU3ZjE0N2JiYmEzMTViMWE1OWNiMzJjY2EyNzk4MDQyY2FlYTBhMWMxOGE3YTBmMzE4MSJ9fX0=";
            case BLUE: this.textureID = "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNDhlYmQ4Yzc4NTg1NzViYzlhOTIwN2FkZTRlYWMxZGIwNGQ2OWI5MDllMzYwMGE3MDBkYTZhNzZhM2Q5ZmYyZSJ9fX0=";
            case PINK: this.textureID = "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvM2MwNzczN2Q4NzY2YjBhZTQyZjI3NDEzMTg0Zjg0ZWJiMjVlNTQwOWI0MmY0NDhjZDY4YmExYWRjYTI5OTUwMyJ9fX0=";
            case AQUA: this.textureID = "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZGVmNDFhMTAzODUzNmQ5NDkyMDIzMzJjZmMyZDcxYTI0YjhlZWEzMDFhMjc4NWQ1MjA2YTNhMThmMWVkYWIwNiJ9fX0=";
        }
    }


}
