package pl.jasmc.presents.listeners;

import net.minecraft.server.v1_12_R1.Block;
import net.minecraft.server.v1_12_R1.NBTTagCompound;
import org.bukkit.Material;
import org.bukkit.craftbukkit.v1_12_R1.inventory.CraftItemStack;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import pl.jasmc.presents.managers.DataManager;
import pl.jasmc.presents.objects.JPlayer;

import java.lang.reflect.Field;

public class JoinEvent implements Listener {

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        JPlayer jPlayer = new JPlayer(event.getPlayer().getUniqueId().toString(), event.getPlayer().getName());
        DataManager.players.add(jPlayer);
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent event) {



        net.minecraft.server.v1_12_R1.ItemStack test = CraftItemStack.asNMSCopy(event.getItemInHand());

        NBTTagCompound compound = (test.hasTag()) ? test.getTag() : new NBTTagCompound();




        System.out.println("Test: " + compound.toString());
    }

}
