package pl.jasmc.presents.managers;

import pl.jasmc.presents.objects.JPlayer;
import pl.jasmc.presents.objects.Present;

import java.util.ArrayList;
import java.util.List;

public class DataManager {

    public static List<Present> loadedPresenents = new ArrayList<>();
    public static List<JPlayer> players = new ArrayList<>();



    public static void addPresent(Present present) {
        loadedPresenents.add(present);

    }





}
