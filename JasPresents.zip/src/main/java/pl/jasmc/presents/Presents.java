package pl.jasmc.presents;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.wrappers.nbt.NbtCompound;
import com.comphenix.protocol.wrappers.nbt.NbtFactory;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import com.zaxxer.hikari.HikariDataSource;
import net.minecraft.server.v1_12_R1.*;
import org.apache.commons.codec.binary.Base64;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.craftbukkit.v1_12_R1.CraftWorld;
import org.bukkit.craftbukkit.v1_12_R1.entity.CraftPlayer;
import org.bukkit.craftbukkit.v1_12_R1.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.yaml.snakeyaml.external.biz.base64Coder.Base64Coder;
import pl.jasmc.presents.commands.PresentCommand;
import pl.jasmc.presents.database.DatabaseConfiguration;
import pl.jasmc.presents.listeners.JoinEvent;
import pl.jasmc.presents.managers.DataManager;
import pl.jasmc.presents.objects.JPlayer;
import pl.jasmc.presents.objects.Present;
import pl.jasmc.presents.packets.WrapperPlayServerTileEntityData;
import pl.jasmc.presents.utils.Utils;
import org.bukkit.Location;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.UUID;

public class Presents extends JavaPlugin {

    private static Presents inst;
    private HikariDataSource hikari;

    private ProtocolManager protocolManager;

    public static Presents getInstance() {
        return inst;
    }

    @Override
    public void onEnable() {
        inst = this;
        protocolManager = ProtocolLibrary.getProtocolManager();
        saveDefaultConfig();
        if (this.getConfig().getBoolean("General.Database.DatabaseUse")) {
            hikari = new HikariDataSource();
            hikari.setDataSourceClassName(this.getConfig().getString("General.Database.DataSourceClass"));
            hikari.addDataSourceProperty("serverName", this.getConfig().getString("General.Database.ServerIP"));
            hikari.addDataSourceProperty("port", this.getConfig().getString("General.Database.ServerPort"));
            hikari.addDataSourceProperty("databaseName", this.getConfig().getString("General.Database.DatabaseName"));
            hikari.addDataSourceProperty("user", this.getConfig().getString("General.Database.DatabaseUser"));
            hikari.addDataSourceProperty("password", this.getConfig().getString("General.Database.DatabasePassword"));

            try {
                DatabaseConfiguration.checkTable();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }



        Bukkit.getScheduler().runTaskLater(this, new Runnable() {
            @Override
            public void run() {
                Utils.sendColoredInfo("&cJasUtilites ============== &6LOADED");
                if (getConfig().getBoolean("General.Database.DatabaseUse")) {
                   Utils.sendColoredInfo("&cDatabase status = &aON");
                    try {
                        DatabaseConfiguration.loadPresents();
                        startPacketTask();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                } else {
                    Utils.sendColoredInfo("&cDatabase status = &4OFF");
                    Utils.sendColoredInfo("&6A lot of functions will doesn't work!");
                }
            }
        }, 80);

        getCommand("prezent").setExecutor(new PresentCommand());
        PluginManager pm = Bukkit.getPluginManager();
        pm.registerEvents(new JoinEvent(), this);

    }

    @Override
    public void onDisable() {
        if (hikari != null) {
            hikari.close();
        }
    }

    public void startPacketTask() {
        ItemStack item = Utils.createSkull("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMjc1ZDEzY2ExNGJjYmJkMWNkZTIxYWEwNjYwMDEwMWU0NTZkMzE4YWFkZjE3OGIyNzkzNjc4YjQ5NGY2ZGNlOCJ9fX0=", "test");
        Bukkit.getScheduler().runTaskTimer(this, new Runnable() {
            @Override
            public void run() {
                for(JPlayer j : DataManager.players) {
                    for(Present p : j.presentsToFind) {
                        //Block block = p.location.getBlock();
                        //block.setType(item.getType());
                        //block.setData(item.getData().getData());
                        //getServer().getPlayer(j.name).sendBlockChange(p.location, item.getType(), item.getData().getData());

                        //setHead(Bukkit.getPlayer(j.name), p.location);


                        placeHead(p.location, Utils.getGameProfile("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMjc1ZDEzY2ExNGJjYmJkMWNkZTIxYWEwNjYwMDEwMWU0NTZkMzE4YWFkZjE3OGIyNzkzNjc4YjQ5NGY2ZGNlOCJ9fX0="), Bukkit.getPlayer(j.name));

                        // System.out.println("Test: " + Utils.getGameProfile("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZjBhZmE0ZmZmZDEwODYzZTc2YzY5OGRhMmM5YzllNzk5YmNmOWFiOWFhMzdkODMxMjg4MTczNDIyNWQzY2EifX19").getProperties().get("textures"));
                        //getServer().getPlayer(j.UUID).sendBlockChange(p.location, item.getType(), item.getData().getData());
                        //PacketBlockChange
                        //EnityData
                    }
                }
            }
        }, 0, 20);

    }

    public void setHead(Player p, Location zLoc) {
        NBTTagCompound skinData = new NBTTagCompound();
        // Set skin data here
        BlockPosition blockPos = new BlockPosition(zLoc.getBlockX(), zLoc.getBlockY(), zLoc.getBlockZ());
        PacketPlayOutTileEntityData packet = new PacketPlayOutTileEntityData(blockPos, 4, skinData);
        // 4: Set rotation and skin of mob head
        ((CraftPlayer) p).getHandle().playerConnection.sendPacket(packet);
    }

    public void placeHead(Location loc, GameProfile skinProfile, Player receiver) {
        loc.getChunk().load();



        BlockPosition blockPosition = new BlockPosition(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
        PacketPlayOutBlockChange blockChange = new PacketPlayOutBlockChange(((CraftWorld) loc.getWorld()).getHandle(), blockPosition);
        IBlockData iBlock =  Blocks.SKULL.getBlockData();
        iBlock.set(BlockSkull.FACING, EnumDirection.EAST).set(BlockSkull.NODROP, true);
        blockChange.block =  iBlock;



        //blockChange.block = net.minecraft.server.v1_12_R1.Block.getByCombinedId((3 << 12) | Material.SKULL.getId());
        NBTTagCompound tag = new NBTTagCompound();


        byte rotation = 5;
        tag.setByte("SkullType", (byte) (3 & 255));



        tag.setByte("Rot", (byte) (rotation & 255));
        NBTTagCompound profTag = new NBTTagCompound();

        GameProfile gameProfile = Utils.getGameProfile("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMjc1ZDEzY2ExNGJjYmJkMWNkZTIxYWEwNjYwMDEwMWU0NTZkMzE4YWFkZjE3OGIyNzkzNjc4YjQ5NGY2ZGNlOCJ9fX0=");

        GameProfileSerializer.serialize(profTag, gameProfile);


        tag.set("SkullOwner", profTag);
        System.out.println(tag.toString());



        NBTTagCompound testt = CraftItemStack.asNMSCopy(setSkullOwner(new ItemStack(Material.SKULL, 1, (short) 3), "596526e6-075c-4bb0-8794-48e90471f766", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZjA5NjcwZDM1MWQ3ODU3ZjE0N2JiYmEzMTViMWE1OWNiMzJjY2EyNzk4MDQyY2FlYTBhMWMxOGE3YTBmMzE4MSJ9fX0=")).getTag();
        //net.minecraft.server.v1_12_R1.ItemStack item = CraftItemStack.asNMSCopy(Utils.createSkull("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMjc1ZDEzY2ExNGJjYmJkMWNkZTIxYWEwNjYwMDEwMWU0NTZkMzE4YWFkZjE3OGIyNzkzNjc4YjQ5NGY2ZGNlOCJ9fX0=", "Test")).getTag();

        ((CraftPlayer) receiver).getHandle().playerConnection.sendPacket(blockChange);
        ((CraftPlayer) receiver).getHandle().playerConnection.sendPacket(new PacketPlayOutTileEntityData(blockPosition, 4, tag));

    }

    public ItemStack setSkullOwner(ItemStack test, String cos, String coss) {
        return null;
    }


    public void sendPacketWithProtocol(Location loc, Player receiver) throws InvocationTargetException {
        receiver.sendBlockChange(loc, Material.SKULL, (byte)2);

        com.comphenix.protocol.wrappers.BlockPosition blockPosition = new com.comphenix.protocol.wrappers.BlockPosition(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
        final PacketContainer blockChange = new PacketContainer(PacketType.Play.Server.BLOCK_CHANGE);
        blockChange.getBlockPositionModifier().write(0, blockPosition);
        protocolManager.sendServerPacket(receiver, blockChange);

        final PacketContainer head = new PacketContainer(PacketType.Play.Server.TILE_ENTITY_DATA);
        head.getBlockPositionModifier().write(0, blockPosition);
        head.getIntegers().write(0, 3);

        String skullTexture = "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZjA5NjcwZDM1MWQ3ODU3ZjE0N2JiYmEzMTViMWE1OWNiMzJjY2EyNzk4MDQyY2FlYTBhMWMxOGE3YTBmMzE4MSJ9fX0=";
        GameProfile gameProfile = new GameProfile(UUID.randomUUID(), null);
        gameProfile.getProperties().put("textures", new Property("textures", Base64Coder.encodeString("{textures:[{Value:\"" + skullTexture + "\"}]}")));

        final NbtCompound compound = NbtFactory.ofCompound("");


        compound.put("textures", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZjA5NjcwZDM1MWQ3ODU3ZjE0N2JiYmEzMTViMWE1OWNiMzJjY2EyNzk4MDQyY2FlYTBhMWMxOGE3YTBmMzE4MSJ9fX0=");
        head.getNbtModifier().write(0, compound);
        //protocolManager.sendServerPacket(receiver, head);


        WrapperPlayServerTileEntityData packet = new WrapperPlayServerTileEntityData();
        packet.setLocation(blockPosition);
        //packet.setNbtData(NbtFactory.fromItemTag(Utils.createSkull("eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZjA5NjcwZDM1MWQ3ODU3ZjE0N2JiYmEzMTViMWE1OWNiMzJjY2EyNzk4MDQyY2FlYTBhMWMxOGE3YTBmMzE4MSJ9fX0=", "Test")));
        //packet.setNbtData(NbtFactory.fromItemTag(Utils.setSkullOwner(new ItemStack(Material.SKULL_ITEM, 1, (byte) 3), UUID.randomUUID().toString(),"eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZjA5NjcwZDM1MWQ3ODU3ZjE0N2JiYmEzMTViMWE1OWNiMzJjY2EyNzk4MDQyY2FlYTBhMWMxOGE3YTBmMzE4MSJ9fX0=")));
        packet.setNbtData(NbtFactory.fromItemTag(Utils.createSkull(skullTexture, "Test")));
        // packet.setNbtData(NbtFactory.fromItemTag((CraftItemStack)Utils.setSkullOwner(new ItemStack(Material.SKULL), "596526e6-075c-4bb0-8794-48e90471f766", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZjA5NjcwZDM1MWQ3ODU3ZjE0N2JiYmEzMTViMWE1OWNiMzJjY2EyNzk4MDQyY2FlYTBhMWMxOGE3YTBmMzE4MSJ9fX0=")));
        //packet.setNbtData(NbtFactory.fromItemTag(new ItemStack(Material.SKULL)));

        //NbtCompound tag = NbtFactory.


        protocolManager.sendServerPacket(receiver, packet.getHandle());
        //packet.getHandle();

    }



    public void packet(Player receiver, Location location) throws InvocationTargetException {
        PacketContainer container = new PacketContainer(PacketType.Play.Server.BLOCK_CHANGE);

        container.getDoubles().write(0, location.getX());
        container.getDoubles().write(1, location.getY());
        container.getDoubles().write(2, location.getZ());

        container.getIntegers().write(0, Material.SKULL.getId());

        container.getBytes().write(0, (byte)3);

        protocolManager.sendServerPacket(receiver, container);

    }

    public void showHead(Player receiver, Location loc) {
        PacketContainer packet = new PacketContainer(PacketType.Play.Client.BLOCK_PLACE);
        //packet.
        try {
            ProtocolLibrary.getProtocolManager().sendServerPacket(receiver, packet);

        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }




    public HikariDataSource getHikari() {
        return hikari;
    }
}
