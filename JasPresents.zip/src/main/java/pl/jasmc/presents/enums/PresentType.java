package pl.jasmc.presents.enums;

public enum PresentType {

    GREEN, AQUA, BLUE, ORANGE, BLU, PINK
}
